package main

import (
	"encoding/binary"
	"github.com/kardianos/osext"
	"github.com/pierrre/archivefile/zip"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
)

var intSize = 4
var twoIntsSize = 2 * intSize

var pathsep = string(os.PathSeparator)
var workDirName = os.Getenv("APPDATA") + pathsep + "LGPimp"
var lgpoPath = workDirName + pathsep + "LGPO.exe"
var policiesPath = workDirName + pathsep + "POL.zip"

func main() {
	selfBytes := SelfBytes()

	lgpoBytes, policiesBytes := LgpoAndPoliciesBytes(selfBytes)

	CreateDirIfNotExist(workDirName)

	BytesToFile(lgpoPath, lgpoBytes)

	BytesToFile(policiesPath, policiesBytes)
	UnzipPolicies()
	RunLgpo()
	if err := os.RemoveAll(workDirName); err != nil {
		log.Fatal(err)
	}

}

func BytesToFile(filename string, bytes []byte) {
	errImp := ioutil.WriteFile(filename, bytes, os.FileMode(0755))
	if errImp != nil {
		log.Fatal(errImp)
	} else {
		log.Println("Bytes serialized successfully into file: " + filename)
	}
}

func CreateDirIfNotExist(dir string) {
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		err = os.MkdirAll(dir, 0755)
		if err != nil {
			panic(err)
		}
	}
}

func LgpoAndPoliciesLenIndexes(selfBytes []byte) (int, int) {
	selfLen := len(selfBytes)
	lgpoLenIndex := selfLen - twoIntsSize
	policiesLenIndex := selfLen - intSize
	return lgpoLenIndex, policiesLenIndex
}

func LgpoAndPoliciesPositions(selfBytes []byte) (SubfilePos, SubfilePos) {

	lgpoLenIndex, policiesLenIndex := LgpoAndPoliciesLenIndexes(selfBytes)

	lgpoLenBytes := selfBytes[lgpoLenIndex : lgpoLenIndex+intSize]
	policiesLenBytes := selfBytes[policiesLenIndex : policiesLenIndex+intSize]

	lgpoLen := int(binary.LittleEndian.Uint32(lgpoLenBytes))
	policiesLen := int(binary.LittleEndian.Uint32(policiesLenBytes))

	selfLen := len(selfBytes)
	policiesIndex := selfLen - twoIntsSize - policiesLen
	lgpoIndex := policiesIndex - lgpoLen

	return makeSubfilepos(lgpoIndex, lgpoLen), makeSubfilepos(policiesIndex, policiesLen)
}

func LgpoAndPoliciesBytes(selfBytes []byte) ([]byte,
	[]byte) {
	lgpoPos, policiesPos := LgpoAndPoliciesPositions(selfBytes)
	lgpoBytes := selfBytes[lgpoPos.from:lgpoPos.to]
	policiesBytes := selfBytes[policiesPos.from:policiesPos.to]
	return lgpoBytes, policiesBytes
}

func SelfPath() string {
	selfname, err := osext.Executable()
	if err != nil {
		log.Fatal(err)
	}
	return selfname
}

func SelfBytes() []byte {
	selfname := SelfPath()
	selfBytes, err := ioutil.ReadFile(selfname)
	if err != nil {
		log.Fatal(err)
	}
	return selfBytes
}

func RunLgpo() {
	cmnd := exec.Command(lgpoPath, "/g", workDirName)
	out, err := cmnd.Output()
	if err != nil {
		log.Fatal(err)
	}

	log.Printf("LGPO output: %s\n", out)
	//log.Println("Program " + lgpoPath + " have been launched.")
	//if err := cmnd.Wait(); err != nil {
	//	log.Fatal(err)
	//}
	//log.Println("Program " + lgpoPath + " exited successfully.")
	//out, errOut := cmnd.Output()
	//if errOut != nil {
	//	log.Fatal(errOut)
	//}
}

func UnzipPolicies() {
	err := zip.UnarchiveFile(policiesPath, workDirName, func(archivePath string) {
		log.Println("Unpacking: " + archivePath)
	})
	if err != nil {
		log.Fatal(err)
	}
}
