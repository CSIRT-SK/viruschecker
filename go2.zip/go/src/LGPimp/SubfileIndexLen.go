package main

type SubfilePos struct {
	from int
	to int
}

func makeSubfilepos(from int, len int) SubfilePos{
	return SubfilePos{from, from + len}
}
