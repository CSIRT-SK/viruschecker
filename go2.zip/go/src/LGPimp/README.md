# LGPO importer

This utility is meant to be used by LGPexp.exe and is unusable just as is.

The app needs the [LGPO.exe](https://www.microsoft.com/en-us/download/details.aspx?id=55319) and zipped 
Local Group Policy backup appended at the end of this utility's executable along with the 2*4 
bytes describing the size of the two appended files. 

## Building

You should have the MS Windows version of [Go](https://golang.org/) compiler installed.

These two commands need to be executed only once.
```bash 
go get github.com/akavel/rsrc

rsrc -manifest LGPIMP.EXE.manifest -o LGPimp.syso
```

Build the executable.
```bash
go build
```

## How to use the executable file

Open the folder where `LGPexp.exe` is located. 
There create a new folder named `dependencies` and copy the `LGPOimp.exe` into this folder.
Place there also the downloaded [LGPO.exe](https://www.microsoft.com/en-us/download/details.aspx?id=55319).

