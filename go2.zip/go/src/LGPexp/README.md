# LGPO importer

The app needs the [LGPO.exe](https://www.microsoft.com/en-us/download/details.aspx?id=55319) and 
LGPimp.exe located in `dependencies` folder at runtime.

## Building

You should have the MS Windows version of [Go](https://golang.org/) compiler installed.

These two commands need to be executed only once.
```bash 
go get github.com/akavel/rsrc

rsrc -manifest LGPexp.EXE.manifest -o LGPexp.syso
```

Build the executable.
```bash
go build
```

## How to use the executable file

Just run `LGPexp.exe` as admin. It should automatically prompt the "Run as administrator" dialog.

It will use the `LGPO.exe` to collect your local group policies.
Then it will create the executable file `PolicyImporter.exe`.
This file represents `LGPimp.exe` with appended `LGPO.exe` + `[Exported policies].zip` + 
`Lengths of LPGO.exe and [Exported policies].zip (8 bytes total)`.

Then simply run `PolicyImporter.exe` on the target machine.

