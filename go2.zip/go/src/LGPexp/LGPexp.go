package main

import (
	"encoding/binary"
	"fmt"
	"github.com/pierrre/archivefile/zip"
	"io"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
)

var pathsep = string(os.PathSeparator)
var lgpoName = "dependencies" + pathsep + "LGPO.exe"
var lgpoImpName = "dependencies" + pathsep + "LGPimp.exe"
var lgpoImpNameFinal = "PolicyImporter.exe"
var exportedPolicyDirName = "POL"

func main() {
	fmt.Print("Exporting")
	RunLgpo()
	FindExportedPoliciesAndRename()
	zipName := ZipPolicies()
	CreateImporter(zipName)
	Cleanup()
}

func Cleanup() {
	if err := os.RemoveAll(exportedPolicyDirName); err != nil {
		log.Fatal(err)
	}
	if err := os.Remove(exportedPolicyDirName + ".zip"); err != nil {
		log.Fatal(err)
	}
}

func CreateImporter(policyZipName string) {
	lgpoImpBytes := FileToBytes(lgpoImpName)
	lgpoBytes := FileToBytes(lgpoName)
	zipBytes := FileToBytes(policyZipName)

	lgpoLen := lenInBytes(lgpoBytes)
	zipLen := lenInBytes(zipBytes)

	lgpoImp_lgpoBytes := append(lgpoImpBytes, lgpoBytes...)
	lgpoImp_lgpo_zipBytes := append(lgpoImp_lgpoBytes, zipBytes...)
	lgpoImp_lgpo_zip_lenBytes := append(lgpoImp_lgpo_zipBytes, lgpoLen...)
	lgpoImpBytesFinal := append(lgpoImp_lgpo_zip_lenBytes, zipLen...)

	BytesToFile(lgpoImpNameFinal, lgpoImpBytesFinal)

	//_, err := CopyFile(lgpoImpName, lgpoImpNameFinal)
	//if err != nil {
	//	log.Fatal(err)
	//}
	//lgpoImpFinal, errof := os.OpenFile(lgpoImpNameFinal, os.O_APPEND | os.O_WRONLY,
	//	os.FileMode(0755))
	//if errof != nil{
	//	log.Fatal(errof)
	//}
	//
	//lgpoBytes := FileToBytes(lgpoName)
	//zipBytes := FileToBytes(policyZipName)
	//
	//lgpoLen := lenInBytes(lgpoBytes)
	//zipLen := lenInBytes(zipBytes)
	//
	//if _, err := lgpoImpFinal.Write(lgpoBytes); err !=nil {
	//	log.Fatal(err)
	//}
	//if _, err := lgpoImpFinal.Write(zipBytes); err !=nil {
	//	log.Fatal(err)
	//}
	//if _, err := lgpoImpFinal.Write(lgpoLen); err !=nil {
	//	log.Fatal(err)
	//}
	//if _, err := lgpoImpFinal.Write(zipLen); err !=nil {
	//	log.Fatal(err)
	//}
	//
	//if err := lgpoImpFinal.Close(); err != nil {
	//	log.Fatal(err)
	//}
}

func CopyFile(src, dst string) (int64, error) {
	sourceFileStat, err := os.Stat(src)
	if err != nil {
		return 0, err
	}

	if !sourceFileStat.Mode().IsRegular() {
		return 0, fmt.Errorf("%s is not a regular file", src)
	}

	source, err := os.Open(src)
	if err != nil {
		return 0, err
	}
	defer source.Close()

	destination, err := os.Create(dst)
	if err != nil {
		return 0, err
	}
	defer destination.Close()
	nBytes, err := io.Copy(destination, source)
	return nBytes, err
}

func lenInBytes(bytes []byte) []byte {
	zipBytesLen := uint32(len(bytes))
	zipBytesLenBytes := make([]byte, 4)
	binary.LittleEndian.PutUint32(zipBytesLenBytes, zipBytesLen)
	return zipBytesLenBytes
}

func FileToBytes(filename string) []byte {
	bytes, errRead := ioutil.ReadFile(filename)
	if errRead != nil {
		log.Fatal(errRead)
	}
	log.Println("File deserialized successfully: " + filename)

	return bytes
}

func BytesToFile(filename string, bytes []byte) {
	errImp := ioutil.WriteFile(filename, bytes, os.FileMode(0755))
	if errImp != nil {
		log.Fatal(errImp)
	}
	log.Println("Bytes serialized successfully into file: " + filename)

}

func ZipPolicies() string {
	zipName := exportedPolicyDirName + ".zip"

	err := zip.ArchiveFile(exportedPolicyDirName, zipName, func(archivePath string) {
		log.Println("Packing: " + archivePath)
	})

	if err != nil {
		log.Fatal(err)
	}

	return zipName
}

func FindExportedPoliciesAndRename() {
	policyDir := FindExportedPolicies()
	policyDirName := policyDir.Name()
	if errRen := os.Rename(policyDirName, exportedPolicyDirName); errRen != nil {
		log.Fatal(errRen)
	}
	log.Println("Exported policies with name " + policyDirName + " have been found and" +
		" renamed to " + exportedPolicyDirName)

}

func FindExportedPolicies() os.FileInfo {
	currDirString := CurrentDir()
	curDirr, err := os.Open(currDirString)
	if err != nil {
		log.Fatal(err)
	}
	files, errRd := curDirr.Readdir(0)
	if errRd != nil {
		log.Fatal(errRd)
	}

	var latestDirIndex = -1
	// Find some dir
	for i := 0; i < len(files); i++ {
		//log.Println("New file found at index " + strconv.Itoa(i) + ": " + files[i].Name())
		if files[i].IsDir() {
			latestDirIndex = i
			//log.Println("First directory found at index " + strconv.Itoa(i) + ": " + files[i].
			//	Name())
			break
		}
	}

	if latestDirIndex == -1 {
		log.Fatal("Cannot find exported policy directory")
		return nil
	}

	// Find latest dir
	for i := latestDirIndex + 1; i < len(files); i++ {
		//log.Println("New file found at index " + strconv.Itoa(i) + ": " + files[i].Name())
		if files[i].IsDir() {
			//log.Println("New directory found at index " + strconv.Itoa(i) + ": " + files[i].Name())
			if files[i].ModTime().After(files[latestDirIndex].ModTime()) {
				//log.Println("New policy directory candidate found at index " + strconv.Itoa(i) + ": " + files[i].Name())
				latestDirIndex = i
			}
		}
	}
	log.Println("Policy directory found at index " + strconv.Itoa(latestDirIndex) + ": " + files[latestDirIndex].
		Name())

	return files[latestDirIndex]
}

func RunLgpo() {
	cmnd := exec.Command(lgpoName, "/b", CurrentDir())
	out, err := cmnd.Output()
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("LGPO output: %s\n", out)
	//log.Println("Program " + lgpoName + " have been launched.")
	//if err := cmnd.Wait(); err != nil {
	//	log.Fatal(err)
	//}
	//log.Println("Program " + lgpoName + " have exited successfully.")
	//out, errOut := cmnd.Output()
	//if errOut != nil {
	//	log.Fatal(errOut)
	//}
	//log.Printf("LGPO output: %s\n", out)
}

func CurrentDir() string {
	dir, err := filepath.Abs(filepath.Dir(os.Args[0]))
	if err != nil {
		log.Fatal(err)
	}
	return dir
}
