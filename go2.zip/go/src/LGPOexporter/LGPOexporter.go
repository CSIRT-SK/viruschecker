package main

import (
	"fmt"
	"os"
)

var pathsep = string(os.PathSeparator)
var groupPolicyPath = os.Getenv("windir") + pathsep +
	"System32" + pathsep +
	"GroupPolicy"

func main() {
	fmt.Println("system dir: ", os.Getenv("windir"))
}
